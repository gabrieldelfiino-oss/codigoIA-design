/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Fredoka"', 'sans-serif'],
      },
      colors: {
        naranja: '#FF6B3B',
        violeta: '#C172FF',
        verde: '#C4FD36',
        azul: '#2400FF',
        'azul-oscuro': '#1A1A30',
        blanco: '#FAFAFA',
        negro: '#050607',
      },
    },
  },
  plugins: [],
}
