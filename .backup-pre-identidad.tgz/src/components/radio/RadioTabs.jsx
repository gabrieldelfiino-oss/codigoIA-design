/**
 * Tabs para elegir qué entrevista de Código IA Radio se muestra en RadioSection.
 * Acento violeta.
 */
export default function RadioTabs({ items, activeId, onSelect }) {
  return (
    <div className="flex flex-wrap gap-2 sm:gap-3">
      {items.map((item) => {
        const isActive = item.id === activeId
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onSelect(item.id)}
            className={[
              'rounded-full border px-4 py-2 text-sm transition-colors sm:text-base',
              isActive
                ? 'border-violeta bg-violeta font-medium text-negro'
                : 'border-white/15 text-blanco/70 hover:border-white/40 hover:text-blanco',
            ].join(' ')}
          >
            {item.titulo}
          </button>
        )
      })}
    </div>
  )
}
