/**
 * Pie de página: fondo negro igual al resto del sitio, wordmark chico,
 * links a redes y copyright.
 */
export default function Footer() {
  return (
    <footer className="w-full border-t border-white/10 bg-negro px-6 py-10 sm:px-10">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
        <span className="font-display text-lg text-blanco">
          Código <span className="text-verde">IA</span>
        </span>

        <div className="flex gap-6 text-sm text-blanco/60">
          <a
            href="https://www.youtube.com/channel/UCoB5ZY5DohkX1Qi19Ju5y_A"
            target="_blank"
            rel="noreferrer"
            className="transition-colors hover:text-blanco"
          >
            YouTube
          </a>
          <a
            href="https://www.instagram.com/codigo.ia/"
            target="_blank"
            rel="noreferrer"
            className="transition-colors hover:text-blanco"
          >
            Instagram
          </a>
        </div>

        <span className="text-sm text-blanco/40">Copyright © 2026</span>
      </div>
    </footer>
  )
}
