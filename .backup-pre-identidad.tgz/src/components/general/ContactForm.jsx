/**
 * Formulario de contacto: por ahora solo UI, sin envío real.
 * Cuando se defina un servicio (EmailJS, Formspree, backend propio),
 * handleSubmit es el único lugar que hay que tocar.
 */
export default function ContactForm() {
  const handleSubmit = (e) => {
    e.preventDefault()
    // TODO: conectar a un servicio de envío cuando se decida cuál usar.
  }

  return (
    <section id="contacto" className="mx-auto max-w-2xl px-6 py-20 sm:px-10">
      <h2 className="mb-8 text-2xl font-semibold text-blanco sm:text-3xl">Contacto</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input
          type="text"
          name="nombre"
          placeholder="Tu nombre"
          className="rounded-lg border border-white/15 bg-transparent px-4 py-3 text-blanco placeholder:text-blanco/40 focus:border-verde focus:outline-none"
        />
        <input
          type="email"
          name="email"
          placeholder="Tu correo electrónico"
          className="rounded-lg border border-white/15 bg-transparent px-4 py-3 text-blanco placeholder:text-blanco/40 focus:border-verde focus:outline-none"
        />
        <input
          type="text"
          name="asunto"
          placeholder="Asunto"
          className="rounded-lg border border-white/15 bg-transparent px-4 py-3 text-blanco placeholder:text-blanco/40 focus:border-verde focus:outline-none"
        />
        <textarea
          name="mensaje"
          placeholder="Tu mensaje (opcional)"
          rows={4}
          className="rounded-lg border border-white/15 bg-transparent px-4 py-3 text-blanco placeholder:text-blanco/40 focus:border-verde focus:outline-none"
        />
        <button
          type="submit"
          className="mt-2 w-fit rounded-full bg-verde px-6 py-3 font-medium text-negro transition-opacity hover:opacity-90"
        >
          Enviar
        </button>
      </form>
    </section>
  )
}
