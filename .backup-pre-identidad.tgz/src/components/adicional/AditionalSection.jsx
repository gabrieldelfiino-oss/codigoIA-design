import { getProgramasPorTemporada, TEMPORADAS } from '../../utils/programas'
import AditionalTabs from './AditionalTabs'

/**
 * Los 4 capítulos temáticos de la Temporada 2 (cine, educación, arte,
 * gamificación). Título enorme y centrado arriba, debajo una grilla de
 * miniaturas tipo "preview de YouTube" que llevan directo al video, con
 * borde naranja para destacarlas.
 */
export default function AditionalSection() {
  const episodios = getProgramasPorTemporada(TEMPORADAS.ADICIONAL)

  if (episodios.length === 0) return null

  return (
    <section id="temporada-2" className="bg-negro">
      <div className="mx-auto max-w-6xl px-6 pb-24 pt-14 sm:px-10 sm:pb-32 sm:pt-20">
        <div className="mx-auto max-w-2xl text-center">
          <p className="mb-4 text-sm uppercase tracking-widest text-naranja">Temporada 2</p>
          <h2 className="text-4xl font-semibold leading-[1.05] text-blanco sm:text-6xl">
            Cuatro miradas sobre un presente intervenido por la IA
          </h2>
          <p className="mx-auto mt-6 max-w-lg text-base text-blanco/55 sm:text-lg">
            Desde los desafíos éticos en el aula hasta las transformaciones en el arte,
            los videojuegos y el cine.
          </p>
        </div>

        <AditionalTabs items={episodios} />
      </div>
    </section>
  )
}
