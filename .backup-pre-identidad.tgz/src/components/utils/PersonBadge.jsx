/**
 * Chip chiquito para mostrar una persona asociada a un programa
 * (ej. "Camila Jurfest (psicóloga, sexóloga clínica)").
 * Se usa en SeasonSection, AditionalSection y RadioSection.
 */
export default function PersonBadge({ children }) {
  return (
    <span className="rounded-full border border-white/15 px-3 py-1 text-xs text-blanco/80 sm:text-sm">
      {children}
    </span>
  )
}
