import { motion } from 'framer-motion'
import logo from '../../utils/logo.png'

/**
 * El mismo bloque (logo + "Código IA") en sus dos estados.
 * El layoutId compartido es lo que le permite a Framer Motion animar
 * la transformación de "título grande centrado" a "logo chico en el header",
 * en vez de tratarlos como dos elementos distintos con fade cruzado.
 * Al estar logo y texto dentro del mismo contenedor animado, se achican
 * juntos como una sola unidad de marca.
 *
 * En su primera aparición (variant="large") entra chico y transparente,
 * y crece hasta su tamaño final.
 */
export default function BrandTitle({ variant = 'large' }) {
  const isLarge = variant === 'large'

  return (
    <motion.div
      layoutId="brand"
      initial={isLarge ? { opacity: 0, scale: 0.4 } : false}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
      className={['flex select-none items-center', isLarge ? 'gap-4 sm:gap-6' : 'gap-2'].join(' ')}
    >
      <img
        src={logo}
        alt="Código IA"
        className={isLarge ? 'h-[12vw] w-[12vw] sm:h-[9vw] sm:w-[9vw]' : 'h-7 w-7 sm:h-8 sm:w-8'}
      />
      <span
        className={[
          'whitespace-nowrap font-display font-semibold leading-none',
          isLarge ? 'text-[16vw] sm:text-[13vw] tracking-tight' : 'text-xl sm:text-2xl tracking-tight',
        ].join(' ')}
      >
        <span className="text-blanco">Código </span>
        <span className="text-verde">IA</span>
      </span>
    </motion.div>
  )
}
